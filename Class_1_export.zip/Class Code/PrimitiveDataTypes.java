package com.syntax.class01;

public class PrimitiveDataTypes {

	public static void main(String[] args) {

		//storing and representing whole number values;
		byte box1 = 10;
		short box2=32767;
		int box3=100000; //popular
		long box4=106558585585858L; //credit cards, transaction id
		
		//storing and representing decimal values;
		float variable1   =   1.99F;
		double variable2   =    99.0;//popular
		
		//storing single characters
		char container='a';
		char dollar='$';
		
		//storing yes or no values
		boolean hot=true;
		boolean tired=false;
		
		System.out.println(variable2);//printing value of the variable
		System.out.println("variable2"); //printing text variable2
		
		System.out.println(tired);
		//System.out.println(variable3); error - variable does not exist
	}

}
