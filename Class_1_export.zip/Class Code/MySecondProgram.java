package com.syntax.class01;

public class MySecondProgram {

	public static void main(String[] args) {
		
		// this is a single line comment

		/* this 
		       is 
		  			multiline comment
		 */
		
		System.out.println("This is my second program");
		
	}

}
